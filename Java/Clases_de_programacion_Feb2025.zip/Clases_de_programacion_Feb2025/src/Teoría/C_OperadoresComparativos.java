package Teoría;

public class C_OperadoresComparativos {
    public static void main(String[] args) {
        int x = 3;
        int y = 2;

        System.out.println("Igualdad: " + (x == y));
        System.out.println("Desigualdad: " + (x != y));
        System.out.println("Mayor a: " + (x > y));
        System.out.println("Menor a: " + (x < y));
        System.out.println("Mayor o igual a: " + (x >= y));
        System.out.println("Menor o igual a: " + (x <= y));

    }
}
