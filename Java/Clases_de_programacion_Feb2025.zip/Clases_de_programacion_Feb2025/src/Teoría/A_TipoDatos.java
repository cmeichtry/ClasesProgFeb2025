package Teoría;

public class A_TipoDatos {

    public static void main(String[] args) {
        int intNum = 31;                    // entero
        float floatNum = 3.1415f;           // numero de punto flotante
        double doubleNum = 33424.31d;         // numero de punto flotante
        char character = 'A';               // caracter
        String text = "Esto es un texto";   // cadena o palabra   
        boolean boolNum = true;             // booleano
        
        System.out.println("Entero: " + intNum);
        System.out.println("Punto flotante (float): " + floatNum);
        System.out.println("Punto flotante (double): " + doubleNum);
        System.out.println("Caracter: " + character);
        System.out.println("Texto: " + text);
        System.out.println("Booleano: " + boolNum);
        
    }
}
