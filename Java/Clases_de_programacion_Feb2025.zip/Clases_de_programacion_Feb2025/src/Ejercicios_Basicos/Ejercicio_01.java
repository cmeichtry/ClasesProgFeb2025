package Ejercicios_Basicos;

public class Ejercicio_01 {

    public static void main(String[] args) {
        //completar según corresponda:
        boolean es_par = true;
        float temperatura = 32.5f;
        String respuesta = "OK";
        char simb = '2';
        int cuenta = 2+2;
    }
}
